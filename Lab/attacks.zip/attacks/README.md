# Programming Project 1

## 小组成员
牛午甲 PB20111656
潘云石 PB20111657
石磊鑫 PB20111658
孙霄鹍 PB20111659
陈&nbsp;&nbsp;&nbsp;&nbsp;昊 PB20051077

## special notes to the grader
- 实验g部分，服务器貌似会对输入的html脚本做些过滤。不过处理方法也很简单，将img和script改成imG和scripT即可。不知道这是不是实验考查的一部分，如果不是，或许可以在以后学期的课程实验中进行改进。

## Reference
- [Javascript 教程](https://www.liaoxuefeng.com/wiki/1022910821149312)
